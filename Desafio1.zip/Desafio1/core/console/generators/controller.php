/**
 * Controlador <?= $class ?>
 * 
 * @category App
 * @package Controllers
 */
class <?= $class ?>Controller extends AppController
{

}
