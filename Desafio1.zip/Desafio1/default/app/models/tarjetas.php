<?php
class Tarjetas extends ActiveRecord{

}