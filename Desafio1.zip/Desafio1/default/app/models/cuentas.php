<?php
class Cuentas extends ActiveRecord{

}