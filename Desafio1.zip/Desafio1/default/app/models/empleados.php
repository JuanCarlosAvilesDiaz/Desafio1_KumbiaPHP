<?php
class Empleados extends ActiveRecord{

}