<?php
class Ciudades extends ActiveRecord{

}