<?php
class Estados extends ActiveRecord{

}