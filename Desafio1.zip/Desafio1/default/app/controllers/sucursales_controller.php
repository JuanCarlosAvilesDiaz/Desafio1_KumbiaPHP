<?php

class SucursalesController extends AppController {

        public function listar (int $page = 1)
        {
                $this->titulo  = 'Tabla de las Sucursales';
                $this->page = (new Sucursales()) ->paginate("page: $page", 'per_page: 10');
                $contador = 0;
                if (count($this->page->items) > 0) {
                        foreach ($this->page->items as $item) {
                               $this->datos[0][$contador] = $item-> id;
                               $this->datos[1][$contador] = $item-> direccion; 
                               $this->datos[2][$contador] = $item-> nombre;
                               $this->datos[3][$contador] = $item-> telefono; 
                               $this->datos[4][$contador] = $item-> abierto; 
                               $this->datos[5][$contador] = $item-> escala; 
                               $contador ++;
                        }
                } else { $this->titulo  = 'No hay Sucursales';  }
                View::template('desafio1');
        }
        
        public function nuevo ()
        {
                $this->titulo  = 'Agregar nueva Sucursal';
                View::template('desafio1'); 
        }

        public function editar ($id)
        {
                $this->titulo  = 'Editar Sucursal';
                View::template('desafio1'); 
                $this->page = (new Sucursales()) ->find($id);
        }
}