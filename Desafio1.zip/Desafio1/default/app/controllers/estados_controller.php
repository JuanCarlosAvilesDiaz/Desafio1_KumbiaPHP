<?php

class EstadosController extends AppController {

        public function listar (int $page = 1)
        {
                $this->titulo  = 'Tabla de los Estados';
                $this->page = (new Estados()) ->paginate("page: $page", 'per_page: 10');
                $contador = 0;
                if (count($this->page->items) > 0) {
                        foreach ($this->page->items as $item) {
                               $this->datos[0][$contador] = $item-> id;
                               $this->datos[1][$contador] = $item-> nombre; 
                               $contador ++;
                        }
                } else { $this->titulo  = 'No hay Estados';  }
                View::template('desafio1'); 
        }
        
        public function nuevo ()
        {
                $this->titulo  = 'Agregar nuevo Estado';
                View::template('desafio1'); 
        }

        public function editar ($id)
        {
                $this->titulo  = 'Editar Estado';
                View::template('desafio1'); 
                $this->page = (new Estados()) ->find($id);
        }
}