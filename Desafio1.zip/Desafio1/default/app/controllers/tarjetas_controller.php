<?php

class TarjetasController extends AppController {

        public function listar (int $page = 1)
        {
                $this->titulo  = 'Tabla de las Tarjetas';
                $this->page = (new Tarjetas()) ->paginate("page: $page", 'per_page: 10');
                $contador = 0;
                if (count($this->page->items) > 0) {
                        foreach ($this->page->items as $item) {
                               $this->datos[0][$contador] = $item-> id;
                               $this->datos[1][$contador] = $item-> saldo_actual; 
                               $this->datos[2][$contador] = $item-> saldo_anterior;
                               $this->datos[3][$contador] = $item-> saldo_maximo; 
                               $this->datos[4][$contador] = $item-> saldo_minumo; 
                               $this->datos[5][$contador] = $item-> nombre_entidad_financiera; 
                               $this->datos[6][$contador] = $item-> es_externa; 
                               $this->datos[7][$contador] = $item-> fecha_utimo_uso; 
                               $this->datos[8][$contador] = $item-> estado; 
                               $this->datos[9][$contador] = $item-> transaciones_maximas;
                               $this->datos[10][$contador] = $item-> transacciones_minimas; 
                               $this->datos[11][$contador] = $item-> tipo;
                               $this->datos[12][$contador] = $item-> acepta_inversion; 
                               $this->datos[13][$contador] = $item-> impuestos; 
                               $this->datos[14][$contador] = $item-> fecha_vencimiento; 
                               $this->datos[15][$contador] = $item-> telefono_asociado; 
                              
                               $contador ++;
                        }
                } else { $this->titulo  = 'No hay Tarjetas';  }
                View::template('desafio1');
        }
        
        public function nuevo ()
        {
                $this->titulo  = 'Agregar nueva Tarjeta';
                View::template('desafio1'); 
        }

        public function editar ($id)
        {
                $this->titulo  = 'Editar Tarjeta';                
                $this->page = (new Tarjetas()) ->find($id);
                if($this->page)
                {
                        $this->titulo  = 'Editar Tarjeta';
                }else $this->titulo  = 'No se encontró la tarjeta';
                View::template('desafio1'); 
        }
}