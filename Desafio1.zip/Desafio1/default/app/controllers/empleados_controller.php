<?php

class EmpleadosController extends AppController {

        public function listar (int $page = 1)
        {
                $this->titulo  = 'Tabla de los Empleados';
                $this->page = (new Empleados()) ->paginate("page: $page", 'per_page: 10');
                $contador = 0;
                if (count($this->page->items) > 0) {
                        foreach ($this->page->items as $item) {
                               $this->datos[0][$contador] = $item-> id;
                               $this->datos[1][$contador] = $item-> nombre; 
                               $this->datos[2][$contador] = $item-> apellidos;
                               $this->datos[3][$contador] = $item-> direccion; 
                               $this->datos[4][$contador] = $item-> nivel; 
                               $this->datos[5][$contador] = $item-> telefono; 
                               $contador ++;
                        }
                } else { $this->titulo  = 'No hay Empleados';  }
                View::template('desafio1'); 
        }
        
        public function nuevo ()
        {
                $this->titulo  = 'Agregar nuevo Empleado';
                View::template('desafio1'); 
        }

        public function editar ($id)
        {
                $this->titulo  = 'Editar Empleado';
                View::template('desafio1'); 
                $this->page = (new Empleados()) ->find($id);
        }
}