<?php

class CiudadesController extends AppController 
{

        public function listar (int $page = 1)
        {
                $this->titulo  = 'Tabla de las ciudades';
                $this->page = (new Ciudades()) ->paginate("page: $page", 'per_page: 10');
                $contador = 0;
                if (count($this->page->items) > 0) {
                        foreach ($this->page->items as $item) {
                               $this->datos[0][$contador] = $item-> id;
                               $this->datos[1][$contador] = $item-> nombre;
                               $this->datos[2][$contador] = $item-> id_estado; 
                               $this->datos[3][$contador] = $item-> tipo; 
                               $contador ++;
                        }
                } else { $this->titulo  = 'No hay ciudades';  }
                View::template('desafio1'); 
        }
        
        public function nuevo ()
        {
                $this->titulo  = 'Agregar nueva ciudad';
                View::template('desafio1'); 
        }

        public function editar ($id)
        {
                $this->titulo  = 'Editar ciudad';
                View::template('desafio1'); 
                $this->page = (new Ciudades()) ->find($id);
        }
}