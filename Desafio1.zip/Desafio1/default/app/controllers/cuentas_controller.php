<?php

class CuentasController extends AppController {

        public function listar (int $page = 1)
        {
                $this->titulo  = 'Tabla de las cuentas';
                $this->page = (new Cuentas()) ->paginate("page: $page", 'per_page: 10');
                $contador = 0;
                if (count($this->page->items) > 0) {
                        foreach ($this->page->items as $item) {
                               $this->datos[0][$contador] = $item-> id;
                               $this->datos[1][$contador] = $item-> id_sucursal; 
                               $this->datos[2][$contador] = $item-> saldo;
                               $this->datos[3][$contador] = $item-> movimientos_maximos; 
                               $contador ++;
                        }
                } else { $this->titulo  = 'No hay cuentas';  }
                View::template('desafio1'); 
        }
        
        public function nuevo ()
        {
                $this->titulo  = 'Agregar nueva Cuenta';
                View::template('desafio1'); 
        }

        public function editar ($id)
        {
                $this->titulo  = 'Editar Cuenta';
                View::template('desafio1'); 
                $this->page = (new Cuentas()) ->find($id);
        }
}