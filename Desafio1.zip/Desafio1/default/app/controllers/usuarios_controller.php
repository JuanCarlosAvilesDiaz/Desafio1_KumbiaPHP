<?php

class UsuariosController extends AppController {

        public function listar (int $page = 1)
        {
                $this->titulo  = 'Tabla de los Usuarios';
                $this->page = (new Usuarios()) ->paginate("page: $page", 'per_page: 10');
                $contador = 0;
                if (count($this->page->items) > 0) {
                        foreach ($this->page->items as $item) {
                               $this->datos[0][$contador] = $item-> id;
                               $this->datos[1][$contador] = $item-> nombre; 
                               $this->datos[2][$contador] = $item-> pass;
                               $this->datos[3][$contador] = $item-> tipo; 
                               $this->datos[4][$contador] = $item-> estado; 
                               $this->datos[5][$contador] = $item-> login_fallidos; 
                               $contador ++;
                        }
                } else { $this->titulo  = 'No hay Usuarios';  }
                View::template('desafio1');
        }
        
        public function nuevo ()
        {
                $this->titulo  = 'Agregar nuevo Usuario';
                View::template('desafio1'); 
        }

        public function editar ($id)
        {
                $this->titulo  = 'Editar Usuario';                
                $this->page = (new Usuarios()) ->find($id);
                if($this->page)
                {
                        $this->titulo  = 'Editar Usuario';
                }else $this->titulo  = 'No se encontró el usuario';
                View::template('desafio1'); 
        }
}